/*
  # Initial Retail Management System Schema

  1. New Tables
    - `product_categories` - Product category management
    - `units` - Measurement units (kg, piece, etc.)
    - `products` - Product information
    - `discounts` - Discount management
    - `suppliers` - Supplier management
    - `customers` - Customer management
    - `employees` - Employee management
    - `roles` - User roles
    - `permissions` - Role permissions
    - `warehouses` - Warehouse management
    - `inventory` - Product inventory tracking
    - `purchases` - Purchase orders
    - `sales` - Sales transactions
    - `sale_items` - Items in sales transactions

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users based on roles
*/

-- Product Categories
CREATE TABLE product_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Units
CREATE TABLE units (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  symbol text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Products
CREATE TABLE products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  description text,
  category_id uuid REFERENCES product_categories(id),
  unit_id uuid REFERENCES units(id),
  price numeric(15,2) NOT NULL DEFAULT 0,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Discounts
CREATE TABLE discounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  discount_type text NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
  value numeric(15,2) NOT NULL,
  product_id uuid REFERENCES products(id),
  category_id uuid REFERENCES product_categories(id),
  start_date timestamptz,
  end_date timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Suppliers
CREATE TABLE suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  contact_person text,
  phone text,
  email text,
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Customers
CREATE TABLE customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text,
  email text,
  address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Roles
CREATE TABLE roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Employees
CREATE TABLE employees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  name text NOT NULL,
  role_id uuid REFERENCES roles(id),
  phone text,
  email text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Warehouses
CREATE TABLE warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  location text,
  created_at timestamptz DEFAULT now()
);

-- Inventory
CREATE TABLE inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id),
  warehouse_id uuid REFERENCES warehouses(id),
  quantity numeric(15,2) NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(product_id, warehouse_id)
);

-- Purchases
CREATE TABLE purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  supplier_id uuid REFERENCES suppliers(id),
  employee_id uuid REFERENCES employees(id),
  total_amount numeric(15,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'cancelled')),
  purchase_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Purchase Items
CREATE TABLE purchase_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_id uuid REFERENCES purchases(id),
  product_id uuid REFERENCES products(id),
  quantity numeric(15,2) NOT NULL,
  unit_price numeric(15,2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Sales
CREATE TABLE sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers(id),
  employee_id uuid REFERENCES employees(id),
  total_amount numeric(15,2) NOT NULL DEFAULT 0,
  discount_amount numeric(15,2) DEFAULT 0,
  final_amount numeric(15,2) NOT NULL DEFAULT 0,
  sale_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

-- Sale Items
CREATE TABLE sale_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id uuid REFERENCES sales(id),
  product_id uuid REFERENCES products(id),
  quantity numeric(15,2) NOT NULL,
  unit_price numeric(15,2) NOT NULL,
  discount_amount numeric(15,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE product_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE units ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE discounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;

-- Create Basic Policies
CREATE POLICY "Authenticated users can read product categories"
  ON product_categories FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can read units"
  ON units FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can read products"
  ON products FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can read discounts"
  ON discounts FOR SELECT TO authenticated USING (true);

-- Insert default roles
INSERT INTO roles (name, description) VALUES
  ('admin', 'System administrator with full access'),
  ('manager', 'Store manager with access to most features'),
  ('cashier', 'Sales and basic inventory operations'),
  ('inventory', 'Inventory management access');

-- Insert default units
INSERT INTO units (name, symbol) VALUES
  ('Kilogram', 'kg'),
  ('Piece', 'pc'),
  ('Package', 'pkg'),
  ('Meter', 'm'),
  ('Liter', 'l');

-- Insert default product categories
INSERT INTO product_categories (name, description) VALUES
  ('لوازم التحریر', 'انواع لوازم التحریر و نوشت‌افزار'),
  ('خواروبار', 'مواد غذایی و خواروبار'),
  ('لوازم خانگی', 'وسایل و لوازم خانگی');