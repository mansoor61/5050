export interface ProductCategory {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
}

export interface Unit {
  id: string;
  name: string;
  symbol: string;
  created_at: string;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  description: string | null;
  category_id: string | null;
  unit_id: string | null;
  price: number;
  image_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Discount {
  id: string;
  name: string;
  description: string | null;
  discount_type: 'percentage' | 'fixed';
  value: number;
  product_id: string | null;
  category_id: string | null;
  start_date: string | null;
  end_date: string | null;
  created_at: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  address: string | null;
  created_at: string;
  updated_at: string;
}