import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { ProductCategory, Unit, Product, Discount } from '../types/database';

interface BasicInfoState {
  categories: ProductCategory[];
  units: Unit[];
  products: Product[];
  discounts: Discount[];
  loading: boolean;
  error: string | null;
  
  // Categories
  fetchCategories: () => Promise<void>;
  addCategory: (name: string, description?: string) => Promise<void>;
  updateCategory: (id: string, name: string, description?: string) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  
  // Units
  fetchUnits: () => Promise<void>;
  addUnit: (name: string, symbol: string) => Promise<void>;
  updateUnit: (id: string, name: string, symbol: string) => Promise<void>;
  deleteUnit: (id: string) => Promise<void>;
  
  // Products
  fetchProducts: () => Promise<void>;
  addProduct: (product: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  
  // Discounts
  fetchDiscounts: () => Promise<void>;
  addDiscount: (discount: Omit<Discount, 'id' | 'created_at'>) => Promise<void>;
  updateDiscount: (id: string, discount: Partial<Discount>) => Promise<void>;
  deleteDiscount: (id: string) => Promise<void>;
}

export const useBasicInfoStore = create<BasicInfoState>((set, get) => ({
  categories: [],
  units: [],
  products: [],
  discounts: [],
  loading: false,
  error: null,

  // Categories
  fetchCategories: async () => {
    try {
      set({ loading: true, error: null });
      const { data, error } = await supabase
        .from('product_categories')
        .select('*')
        .order('name');
      
      if (error) throw error;
      set({ categories: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  addCategory: async (name, description) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('product_categories')
        .insert([{ name, description }]);
      
      if (error) throw error;
      await get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  updateCategory: async (id, name, description) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('product_categories')
        .update({ name, description, updated_at: new Date().toISOString() })
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  deleteCategory: async (id) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('product_categories')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchCategories();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  // Units
  fetchUnits: async () => {
    try {
      set({ loading: true, error: null });
      const { data, error } = await supabase
        .from('units')
        .select('*')
        .order('name');
      
      if (error) throw error;
      set({ units: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  addUnit: async (name, symbol) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('units')
        .insert([{ name, symbol }]);
      
      if (error) throw error;
      await get().fetchUnits();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  updateUnit: async (id, name, symbol) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('units')
        .update({ name, symbol })
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchUnits();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  deleteUnit: async (id) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('units')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchUnits();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  // Products
  fetchProducts: async () => {
    try {
      set({ loading: true, error: null });
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          product_categories (id, name),
          units (id, name, symbol)
        `)
        .order('name');
      
      if (error) throw error;
      set({ products: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  addProduct: async (product) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('products')
        .insert([product]);
      
      if (error) throw error;
      await get().fetchProducts();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  updateProduct: async (id, product) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('products')
        .update({ ...product, updated_at: new Date().toISOString() })
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchProducts();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  deleteProduct: async (id) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchProducts();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  // Discounts
  fetchDiscounts: async () => {
    try {
      set({ loading: true, error: null });
      const { data, error } = await supabase
        .from('discounts')
        .select(`
          *,
          products (id, name),
          product_categories (id, name)
        `)
        .order('name');
      
      if (error) throw error;
      set({ discounts: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  addDiscount: async (discount) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('discounts')
        .insert([discount]);
      
      if (error) throw error;
      await get().fetchDiscounts();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  updateDiscount: async (id, discount) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('discounts')
        .update(discount)
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchDiscounts();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  deleteDiscount: async (id) => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase
        .from('discounts')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      await get().fetchDiscounts();
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },
}));