import React, { useState } from 'react';
import { useBasicInfoStore } from '../stores/useBasicInfoStore';
import { toast } from 'react-hot-toast';

interface CategoryFormProps {
  onClose: () => void;
  editingCategory?: {
    id: string;
    name: string;
    description: string | null;
  };
}

export function CategoryForm({ onClose, editingCategory }: CategoryFormProps) {
  const [name, setName] = useState(editingCategory?.name ?? '');
  const [description, setDescription] = useState(editingCategory?.description ?? '');
  
  const { addCategory, updateCategory } = useBasicInfoStore();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingCategory) {
        await updateCategory(editingCategory.id, name, description);
        toast.success('گروه کالا با موفقیت بروزرسانی شد');
      } else {
        await addCategory(name, description);
        toast.success('گروه کالا با موفقیت ایجاد شد');
      }
      onClose();
    } catch (error) {
      toast.error('خطا در ثبت اطلاعات');
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="name" className="block text-sm font-medium text-gray-700">
          نام گروه
        </label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          required
        />
      </div>
      
      <div>
        <label htmlFor="description" className="block text-sm font-medium text-gray-700">
          توضیحات
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={3}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>
      
      <div className="flex justify-end gap-2">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
        >
          انصراف
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
        >
          {editingCategory ? 'بروزرسانی' : 'ایجاد'}
        </button>
      </div>
    </form>
  );
}