import React, { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useBasicInfoStore } from '../../stores/useBasicInfoStore';
import { Modal } from '../Modal';
import { CategoryForm } from '../CategoryForm';
import { toast } from 'react-hot-toast';

export function Categories() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<{
    id: string;
    name: string;
    description: string | null;
  } | null>(null);
  
  const { categories, fetchCategories, deleteCategory, loading } = useBasicInfoStore();
  
  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);
  
  const handleDelete = async (id: string) => {
    if (window.confirm('آیا از حذف این گروه کالا اطمینان دارید؟')) {
      try {
        await deleteCategory(id);
        toast.success('گروه کالا با موفقیت حذف شد');
      } catch (error) {
        toast.error('خطا در حذف گروه کالا');
      }
    }
  };
  
  const handleEdit = (category: typeof editingCategory) => {
    setEditingCategory(category);
    setIsModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingCategory(null);
  };
  
  if (loading) {
    return <div>در حال بارگذاری...</div>;
  }
  
  return (
    <div>
      <div className="mb-4 flex justify-between items-center">
        <h2 className="text-lg font-semibold">گروه‌های کالا</h2>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          <span>گروه جدید</span>
        </button>
      </div>
      
      <div className="bg-white rounded-lg shadow">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                نام
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                توضیحات
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                عملیات
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {categories.map((category) => (
              <tr key={category.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {category.name}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  {category.description}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(category)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(category.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingCategory ? 'ویرایش گروه کالا' : 'گروه کالای جدید'}
      >
        <CategoryForm
          onClose={handleCloseModal}
          editingCategory={editingCategory ?? undefined}
        />
      </Modal>
    </div>
  );
}