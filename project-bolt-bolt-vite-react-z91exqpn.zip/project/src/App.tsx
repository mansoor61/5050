import React, { useState } from 'react';
import { 
  ShoppingCart, 
  Package, 
  Users, 
  BarChart3, 
  Settings,
  Search,
  Plus,
  Store,
  Minus,
  Trash2,
  Building2,
  Tags,
  Ruler,
  Percent
} from 'lucide-react';

interface Product {
  id: number;
  name: string;
  price: number;
  stock: number;
}

interface CartItem extends Product {
  quantity: number;
}

function App() {
  const [activeTab, setActiveTab] = useState('pos');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  
  const demoProducts: Product[] = [
    { id: 1, name: 'محصول ۱', price: 250000, stock: 50 },
    { id: 2, name: 'محصول ۲', price: 180000, stock: 35 },
    { id: 3, name: 'محصول ۳', price: 320000, stock: 20 },
  ];

  const addToCart = (product: Product) => {
    setCart(currentCart => {
      const existingItem = currentCart.find(item => item.id === product.id);
      if (existingItem) {
        return currentCart.map(item =>
          item.id === product.id && item.quantity < item.stock
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...currentCart, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(currentCart => currentCart.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart(currentCart =>
      currentCart.map(item => {
        if (item.id === productId) {
          const newQuantity = item.quantity + delta;
          if (newQuantity > 0 && newQuantity <= item.stock) {
            return { ...item, quantity: newQuantity };
          }
        }
        return item;
      })
    );
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const renderBasicInfoSection = () => (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <Tags className="w-6 h-6 text-blue-600" />
          <h3 className="text-lg font-semibold">گروه‌های کالا</h3>
        </div>
        <p className="text-gray-600">مدیریت دسته‌بندی محصولات</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <Package className="w-6 h-6 text-green-600" />
          <h3 className="text-lg font-semibold">کالاها</h3>
        </div>
        <p className="text-gray-600">مدیریت محصولات و موجودی</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <Ruler className="w-6 h-6 text-purple-600" />
          <h3 className="text-lg font-semibold">واحدهای سنجش</h3>
        </div>
        <p className="text-gray-600">مدیریت واحدهای اندازه‌گیری</p>
      </div>
      <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <Percent className="w-6 h-6 text-red-600" />
          <h3 className="text-lg font-semibold">تخفیف‌ها</h3>
        </div>
        <p className="text-gray-600">مدیریت تخفیف‌های محصولات</p>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100" dir="rtl">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-4">
          <div className="flex items-center gap-2 mb-8">
            <Store className="w-8 h-8 text-blue-600" />
            <h1 className="text-xl font-bold text-gray-800">سیستم خرده‌فروشی</h1>
          </div>
          <nav>
            <button 
              onClick={() => setActiveTab('pos')}
              className={`flex items-center gap-2 w-full p-3 rounded-lg mb-2 ${
                activeTab === 'pos' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <ShoppingCart className="w-5 h-5" />
              <span>فروش</span>
            </button>
            <button 
              onClick={() => setActiveTab('inventory')}
              className={`flex items-center gap-2 w-full p-3 rounded-lg mb-2 ${
                activeTab === 'inventory' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Package className="w-5 h-5" />
              <span>انبار</span>
            </button>
            <button 
              onClick={() => setActiveTab('basic-info')}
              className={`flex items-center gap-2 w-full p-3 rounded-lg mb-2 ${
                activeTab === 'basic-info' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Building2 className="w-5 h-5" />
              <span>اطلاعات پایه</span>
            </button>
            <button 
              onClick={() => setActiveTab('customers')}
              className={`flex items-center gap-2 w-full p-3 rounded-lg mb-2 ${
                activeTab === 'customers' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Users className="w-5 h-5" />
              <span>مشتریان</span>
            </button>
            <button 
              onClick={() => setActiveTab('reports')}
              className={`flex items-center gap-2 w-full p-3 rounded-lg mb-2 ${
                activeTab === 'reports' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span>گزارشات</span>
            </button>
            <button 
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 w-full p-3 rounded-lg mb-2 ${
                activeTab === 'settings' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Settings className="w-5 h-5" />
              <span>تنظیمات</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <header className="bg-white shadow-sm">
          <div className="px-6 py-4">
            <h2 className="text-xl font-semibold text-gray-800">
              {activeTab === 'pos' && 'صندوق فروش'}
              {activeTab === 'inventory' && 'مدیریت انبار'}
              {activeTab === 'basic-info' && 'اطلاعات پایه'}
              {activeTab === 'customers' && 'مدیریت مشتریان'}
              {activeTab === 'reports' && 'گزارشات'}
              {activeTab === 'settings' && 'تنظیمات سیستم'}
            </h2>
          </div>
        </header>

        <main className="p-6">
          <div className="mb-6 flex gap-4">
            <div className="relative flex-1">
              <Search className="w-5 h-5 absolute right-3 top-2.5 text-gray-400" />
              <input
                type="text"
                placeholder="جستجو..."
                className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <Plus className="w-5 h-5" />
              <span>افزودن جدید</span>
            </button>
          </div>

          {activeTab === 'basic-info' && renderBasicInfoSection()}

          {activeTab === 'inventory' && (
            <div className="bg-white rounded-lg shadow">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">کد</th>
                    <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">نام محصول</th>
                    <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">قیمت</th>
                    <th className="px-6 py-3 text-right text-sm font-medium text-gray-500">موجودی</th>
                  </tr>
                </thead>
                <tbody>
                  {demoProducts.map((product) => (
                    <tr key={product.id} className="border-b hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm text-gray-900">{product.id}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{product.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{product.price.toLocaleString()} ریال</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{product.stock}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'pos' && (
            <div className="grid grid-cols-3 gap-6">
              <div className="col-span-2 bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">محصولات</h3>
                <div className="grid grid-cols-3 gap-4">
                  {demoProducts.map((product) => (
                    <div 
                      key={product.id} 
                      className="border rounded-lg p-4 hover:border-blue-500 cursor-pointer transition-all"
                      onClick={() => addToCart(product)}
                    >
                      <h4 className="font-medium">{product.name}</h4>
                      <p className="text-gray-600 mt-2">{product.price.toLocaleString()} ریال</p>
                      <p className="text-sm text-gray-500 mt-1">موجودی: {product.stock}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">سبد خرید</h3>
                <div className="space-y-4">
                  <div className="max-h-[400px] overflow-y-auto space-y-3">
                    {cart.map((item) => (
                      <div key={item.id} className="flex items-center justify-between border-b pb-3">
                        <div>
                          <h4 className="font-medium">{item.name}</h4>
                          <p className="text-sm text-gray-600">{item.price.toLocaleString()} ریال</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => updateQuantity(item.id, -1)}
                            className="p-1 hover:bg-gray-100 rounded"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-8 text-center">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, 1)}
                            className="p-1 hover:bg-gray-100 rounded"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => removeFromCart(item.id)}
                            className="p-1 hover:bg-red-100 text-red-600 rounded ml-2"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="border-t pt-4">
                    <p className="text-lg font-medium">مجموع: {calculateTotal().toLocaleString()} ریال</p>
                  </div>
                  <button 
                    className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 disabled:bg-gray-400"
                    disabled={cart.length === 0}
                  >
                    ثبت فاکتور
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;